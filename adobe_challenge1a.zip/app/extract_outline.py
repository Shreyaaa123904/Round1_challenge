import os
import json
import fitz  # PyMuPDF
import re

# Clean extra spacing
def clean_text(text):
    text = re.sub(r"\s{2,}", " ", text)
    return text.strip() + " "

# Determine heading level by numbering and size
def classify_heading(text, font_size):
    if re.match(r"^\d+\.\d+\.\d+", text):
        return "H3"
    elif re.match(r"^\d+\.\d+", text):
        return "H2"
    elif re.match(r"^\d+\.", text):
        return "H1"
    elif "Revision History" in text or "Acknowledgements" in text or "Table of Contents" in text:
        return "H1"
    elif "Trademarks" in text or "Web Sites" in text:
        return "H2"
    return None

# Extract best candidate title from top of first page
def extract_title(page):
    blocks = page.get_text("dict")["blocks"]
    lines = []
    for block in blocks:
        if "lines" not in block:
            continue
        for line in block["lines"]:
            line_text = ""
            is_bold = False
            max_size = 0
            for span in line["spans"]:
                line_text += span["text"] + " "
                max_size = max(max_size, span["size"])
                if "Bold" in span.get("font", ""):
                    is_bold = True
            if is_bold and max_size >= 14:
                lines.append(line_text.strip())
    return clean_text("  ".join(lines[:2]))

# Ignore short tokens like "1." or "2.3"
def is_invalid(text):
    return re.fullmatch(r"\d+\.?", text) or len(text.split()) <= 1

# Ignore pages that are TOC-heavy (based on token count)
def is_toc_page(text):
    lines = text.splitlines()
    match_count = sum(1 for line in lines if re.match(r"^\d+(\.\d+)*\s", line))
    return match_count >= 5  # if 5+ lines look like "1.2 ..." — likely a TOC page

def extract_outline_from_pdf(filepath):
    doc = fitz.open(filepath)
    title = extract_title(doc.load_page(0))
    outline = []

    for page_num in range(len(doc)):
        page = doc.load_page(page_num)
        text_dump = page.get_text()

        # Skip TOC pages
        if is_toc_page(text_dump):
            continue

        blocks = page.get_text("dict")["blocks"]

        for block in blocks:
            if "lines" not in block:
                continue
            for line in block["lines"]:
                line_text = ""
                sizes = []
                for span in line["spans"]:
                    line_text += span["text"] + " "
                    sizes.append(span["size"])

                cleaned = clean_text(line_text)
                if is_invalid(cleaned.strip()):
                    continue

                avg_size = sum(sizes) / len(sizes) if sizes else 0
                level = classify_heading(cleaned.strip(), avg_size)
                if level:
                    outline.append({
                        "level": level,
                        "text": cleaned,
                        "page": page_num + 1
                    })

    return {"title": title, "outline": outline}

def process_folder(input_dir, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    for file in os.listdir(input_dir):
        if file.endswith(".pdf"):
            result = extract_outline_from_pdf(os.path.join(input_dir, file))
            with open(os.path.join(output_dir, file.replace(".pdf", ".json")), "w", encoding="utf-8") as f:
                json.dump(result, f, indent=2, ensure_ascii=False)

if __name__ == "__main__":
    process_folder("/app/input", "/app/output")
